-This porgram counts the amount of word pairs in any file(s)

-To compile this program simply type 'make' into the command line where the Makefile is located

-To run run one of the two commands:
   1) ./pairsofwords <-number> <file1> <file2> ...
      -this command will print the top <-number> of word pairs in descending order

   2) ./pairsofwords <file1> <file2> ...
      -this command will print all the word pairs in descending order

-Then run 'make clean' to start new by deleting the .o files and the executable 'pairsofwords'
